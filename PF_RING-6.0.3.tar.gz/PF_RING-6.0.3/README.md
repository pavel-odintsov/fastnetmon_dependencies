# PF_RING
PF_RING is a Linux kernel module and user-space framework that allows
you to process packets at high-rates while providing you a consistent
API for packet processing applications.


