# Copyright 2006 Vladimir Prus
# Distributed under the Boost Software License, Version 1.0.
# (See accompanying file LICENSE_1_0.txt or http://www.boost.org/LICENSE_1_0.txt)

This example shows how to declare a new generator class. It is necessary when
generator's logic is more complex that just running a single tool.
